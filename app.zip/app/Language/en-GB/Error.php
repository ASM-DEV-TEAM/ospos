<?php

return [
    "no_permission_module" => "You do not have the permission to access the module named",
    "unknown"              => "Unexpected error",
];
