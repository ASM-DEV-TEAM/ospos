<?php

return [
    "all"                  => "All",
    "columns"              => "Columns",
    "hide_show_pagination" => "Hide/Show pagination",
    "loading"              => "Loading, please wait...",
    "page_from_to"         => "Showing {0} to {1} of {2} rows",
    "refresh"              => "Refresh",
    "rows_per_page"        => "{0} rows per page",
    "toggle"               => "Toggle",
];
