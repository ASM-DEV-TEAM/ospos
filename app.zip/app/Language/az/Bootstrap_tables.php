<?php

return [
    "all"                  => "hamısı",
    "columns"              => "Sütunlar",
    "hide_show_pagination" => "Gizlət/Göstər səhifənin nömrələnməsin",
    "loading"              => "Lütfən gözləyin, səhifə yüklənir...",
    "page_from_to"         => "Göstər {0} bundan {1} buna {2} kimi",
    "refresh"              => "Yenilə",
    "rows_per_page"        => "{0} yazı səhifədə",
    "toggle"               => "Keçid",
];
