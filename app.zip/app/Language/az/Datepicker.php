<?php

return [
    "all_time"                         => "Bütün vaxta",
    "apply"                            => "Uygula",
    "cancel"                           => "İmtina",
    "custom"                           => "Fərqli",
    "from"                             => "Bundan",
    "last_30"                          => "Son 30 gün",
    "last_7"                           => "Son 7 Gün",
    "last_financial_year"              => "Son Maliyyə ili",
    "last_month"                       => "Ötən ay",
    "last_year"                        => "Ötən il",
    "same_month_last_year"             => "Ötən il eyni ay",
    "same_month_to_same_day_last_year" => "Ötən ilin eyni ayindan",
    "this_financial_year"              => "Cari maliyyə ili",
    "this_month"                       => "Bu ay",
    "this_year"                        => "Bu il",
    "to"                               => "Buna",
    "today"                            => "Bugün",
    "today_last_year"                  => "Keçən il bu gün",
    "weekstart"                        => "0",
    "yesterday"                        => "Dünən",
];
