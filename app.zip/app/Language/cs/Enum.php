<?php

return [
    "half_down"  => "",
    "half_even"  => "",
    "half_five"  => "",
    "half_odd"   => "",
    "half_up"    => "",
    "round_down" => "",
    "round_up"   => "",
];
