<?php

return [
    "all_time"                         => "Vše",
    "apply"                            => "Použít",
    "cancel"                           => "Zrušit",
    "custom"                           => "Jiný",
    "from"                             => "Od",
    "last_30"                          => "Posledních 30 dnů",
    "last_7"                           => "Posledních 7 dnů",
    "last_financial_year"              => "Minulý účetní rok",
    "last_month"                       => "Minulý měsíc",
    "last_year"                        => "Minulý rok",
    "same_month_last_year"             => "Stejný měsíc v loňském roce",
    "same_month_to_same_day_last_year" => "Stejné období loni",
    "this_financial_year"              => "Aktuální účetní rok",
    "this_month"                       => "Tento měsíc",
    "this_year"                        => "Tento rok",
    "to"                               => "Do",
    "today"                            => "Dnes",
    "today_last_year"                  => "Stejný den loni",
    "weekstart"                        => "0",
    "yesterday"                        => "Včera",
];
