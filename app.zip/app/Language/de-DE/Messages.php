<?php

return [
    "first_name"            => "Vorname",
    "last_name"             => "Nachname",
    "message"               => "Nachricht",
    "message_placeholder"   => "Ihre Nachricht hier …",
    "message_required"      => "Nachricht ist ein Pflichtfeld",
    "multiple_phones"       => "(Im Falle von mehreren Handynummern diese bitte mit Kommas getrennt hier eingeben)",
    "phone"                 => "Handynummer",
    "phone_number_required" => "Handynummer ist ein Pflichtfeld",
    "phone_placeholder"     => "Handy-Nummer(n) hier.....",
    "sms_send"              => "SMS Senden",
    "successfully_sent"     => "Nachricht erfolgreich gesendet an: ",
    "unsuccessfully_sent"   => "Nachricht NICHT erfolgreich gesendet an: ",
];
