<?php

return [
    "gcaptcha"                      => "",
    "go"                            => "Start",
    "invalid_gcaptcha"              => "",
    "invalid_installation"          => "",
    "invalid_username_and_password" => "Ungültiger Benutzername/Passwort",
    "login"                         => "Login",
    "logout"                        => "",
    "migration_needed"              => "",
    "password"                      => "Passwort",
    "required_username"             => "",
    "username"                      => "Benutzername",
    "welcome"                       => "",
];
