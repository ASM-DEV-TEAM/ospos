<?php

return [
    'all_time' => "هەموو کاتەکان",
    'apply' => "جێبەجێ کردن",
    'cancel' => "هەڵوەشاندنەوە",
    'custom' => "لەسەرداواکاری",
    'from' => "لە",
    'last_30' => "کۆتا ٣٠ ڕۆژ",
    'last_7' => "کۆتا ٧ ڕۆژ",
    'last_financial_year' => "کۆتا ساڵی دارایی",
    'last_month' => "کۆتا مانگ",
    'last_year' => "ساڵی پێشوو",
    'same_month_last_year' => "هەمان مانگ ساڵی پێشوو",
    'same_month_to_same_day_last_year' => "هەمان مانگ هەتا هەمان ڕۆژی ساڵی پێشوو",
    'this_financial_year' => "ئەم ساڵی داراییە",
    'this_month' => "ئەم مانگە",
    'this_year' => "ئەم ساڵ",
    'to' => "بۆ",
    'today' => "ئەمڕۆ",
    'today_last_year' => "ئەمڕۆ ساڵی ڕابردوو",
    'weekstart' => "0",
    'yesterday' => "دوێنێ",
];
