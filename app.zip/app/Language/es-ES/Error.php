<?php

return [
    "no_permission_module" => "No tienes permiso para accesar el módulo llamado",
    "unknown"              => "desconocido",
];
