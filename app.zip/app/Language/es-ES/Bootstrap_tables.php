<?php

return [
    "all"                  => "Todas",
    "columns"              => "Columnas",
    "hide_show_pagination" => "Ocultar/Mostrar paginación",
    "loading"              => "Por favor espere...",
    "page_from_to"         => "Mostrando desde {0} hasta {1} - En total {2} resultados",
    "refresh"              => "Refrescar",
    "rows_per_page"        => "{0} resultados por página",
    "toggle"               => "Ocultar/Mostrar",
];
