<?php

return [
    "gcaptcha"                      => "No soy un robot.",
    "go"                            => "Ir",
    "invalid_gcaptcha"              => "Por favor verifique si usted no es un robot.",
    "invalid_installation"          => "La instalación no es correcta, comprueba el fichero php.ini.",
    "invalid_username_and_password" => "Usuario y/o Contraseña no validos.",
    "login"                         => "Iniciar Sesión",
    "logout"                        => "Cerrar sesión",
    "migration_needed"              => "La migración de la base de datos a {0} se iniciará después del inicio de sesión.",
    "password"                      => "Contraseña",
    "required_username"             => "El campo de nombre de usuario es obligatorio.",
    "username"                      => "Usuario",
    "welcome"                       => "Bienvenido a {0}!",
];
