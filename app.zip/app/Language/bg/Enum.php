<?php

return [
    "half_down"  => "Half Down",
    "half_even"  => "Half Even",
    "half_five"  => "Half Five",
    "half_odd"   => "Half Odd",
    "half_up"    => "Half Up",
    "round_down" => "Round Down",
    "round_up"   => "Round Up",
];
